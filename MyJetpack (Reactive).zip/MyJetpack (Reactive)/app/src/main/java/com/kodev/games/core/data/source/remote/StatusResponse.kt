package com.kodev.games.core.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}