package com.kodev.games.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}