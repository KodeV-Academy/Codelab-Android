package com.kodev.games.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
